export type BaseApi = {
    error: boolean,
    loading: boolean,
    response: any
}