export type Code = {
    code?: string;
    codeName?: string;
}