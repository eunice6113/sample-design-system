export interface SearchParams {
    type1?: any;
    type2?: any;
    type3?: any;
    searchValue?: string;
    fromDate?: Date | undefined;
    toDate?: Date | undefined;
}
