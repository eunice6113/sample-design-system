export interface TableSortParams {
    sort1?: any;
    sort2?: any;
}
