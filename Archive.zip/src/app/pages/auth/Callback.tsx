import * as React from "react";

const Callback: React.FC = () => {

    return(
    <>
        <h1>Callback</h1>
    </>)
}
export default Callback;