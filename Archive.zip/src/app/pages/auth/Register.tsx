import * as React from "react";
import { useState, useEffect } from "react";
import { BasePage } from "../../shared/components/base/BasePage";

interface IProps {
    children: React.ReactNode;
}

export const Register: React.FC<IProps> = ({children}) => {

    return(
    <>
        <h1>Register !!</h1>

    </>)
}
