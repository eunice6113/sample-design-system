import * as React from "react";
import { BasePage } from "../../shared/components/base/BasePage";
import './ui-guide.css';

const InfoGuide: React.FC = () => {

    //alert
    // confirm
    
    return(
    <BasePage>


    
    </BasePage>)
}
export default InfoGuide;