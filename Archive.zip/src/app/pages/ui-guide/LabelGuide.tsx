import * as React from "react";
import { BasePage } from "../../shared/components/base/BasePage";
import './ui-guide.css';

const LabelGuide: React.FC = () => {

    return(
    <BasePage>

    
    </BasePage>)
}
export default LabelGuide;