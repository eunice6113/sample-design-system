import * as React from "react";
import { BasePage } from "../../shared/components/base/BasePage";
import './ui-guide.css';

const ToggleGuide: React.FC = () => {

    //toggle switch
    //toggle button
    
    return(
    <BasePage>

    
    </BasePage>)
}
export default ToggleGuide;