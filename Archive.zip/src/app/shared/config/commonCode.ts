


export const METHOD = {
    GET : 'GET',
    DELETE : 'DELETE',
    POST : 'POST',
    PUT : 'PUT'
};

export const MODE = {
    VIEW: 'view',
    EDIT: 'edit',
    REGISTER: 'register',
}