//[결재업무]
export const approvalDummyData = [
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
    {
        no: 0,
        type: '01',
        subject: '제목입니다',
        state: '사용',
    },
   
]