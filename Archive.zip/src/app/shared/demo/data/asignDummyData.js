import { Button } from 'primereact/button';
import { InputText } from 'primereact';


//[결재업무]
export const asignDummyData = [
    {
        no:' ',
        department: '기타',
        name: '이권희',
        position: '차장',
    },
    {
        no: <Button className='outline' label='지정'/>,
        department:<InputText className="" placeholder="부서명"/>,
        name: <InputText className="" placeholder="성명"/>,
        position: <InputText className="" placeholder="직급"/>,
        delt:<Button className='iconBtn p-button-text' icon='pi pi-trash' />,
    },
    {
        no: <Button className='outline' label='지정'/>,
        department:<InputText className="" placeholder="부서명"/>,
        name: <InputText className="" placeholder="성명"/>,
        position: <InputText className="" placeholder="직급"/>,
        delt:<Button className='iconBtn p-button-text' icon='pi pi-trash' />,
    },
    {
        no: <Button className='outline' label='지정'/>,
        department:<InputText className="" placeholder="부서명"/>,
        name: <InputText className="" placeholder="성명"/>,
        position: <InputText className="" placeholder="직급"/>,
        delt:<Button className='iconBtn p-button-text' icon='pi pi-trash' />,
    },
    {
        no: <Button className='outline' label='지정'/>,
        department:<InputText className="" placeholder="부서명"/>,
        name: <InputText className="" placeholder="성명"/>,
        position: <InputText className="" placeholder="직급"/>,
        delt:<Button className='iconBtn p-button-text' icon='pi pi-trash' />,
    },
    
   
]