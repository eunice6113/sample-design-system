import { InputText } from 'primereact';

//api 등록
export const bwsApiDummyData = [
    {
        no: 1,
        name: <InputText placeholder='API명을 입력하세요.' />,
        url: <InputText placeholder='URL을 입력하세요.' />,
    },
    
]