//[결재내역]
export const bwsCodePopDummyData = [
    {
        no: 1,
        code: 'HJP',
        name: '홈페이지',
    },
    {
        no: 2,
        code: 'IBK',
        name: '홈페이지',
    },
    {
        no: 3,
        code: 'HJP',
        name: '아이원잡',
    },
    {
        no: 4,
        code: 'IBK',
        name: '홈페이지',
    },
    {
        no: 5,
        code: 'HJP',
        name: '아이원잡',
    },
    {
        no: 6,
        code: 'IBK',
        name: '홈페이지',
    },
    {
        no: 7,
        code: 'HJP',
        name: '아이원잡',
    },
    {
        no: 8,
        code: 'IBK',
        name: '홈페이지',
        service: '2',
        author: '신재문',
        registerDate: '2022.12.05 10:00:00',
    },
    {
        no: 9,
        code: 'HJP',
        name: '아이원잡',
        service: '3',
        author: '이희교',
        registerDate: '2022.12.05 10:00:00',
    },
    {
        no: 10,
        code: 'IBK',
        name: '홈페이지',
        service: '2',
        author: '신재문',
        registerDate: '2022.12.05 10:00:00',
    },
    {
        no: 11,
        code: 'HJP',
        name: '아이원잡',
        service: '3',
        author: '이희교',
        registerDate: '2022.12.05 10:00:00',
    },
    {
        no: 12,
        code: 'IBK',
        name: '홈페이지',
        service: '2',
        author: '신재문',
        registerDate: '2022.12.05 10:00:00',
    },
]