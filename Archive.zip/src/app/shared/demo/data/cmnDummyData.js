//[공지사항]
export const cmnDummyData = [
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 1,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 2,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 3,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 4,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 5,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 6,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 7,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 8,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 9,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 10,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 10,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    {
        no: 10,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: '1,548',
        upvote:'548',
        registerDate: '2022-10-15'
    },
    
]