export const commDummyData = [
    {
        id: 'c0',
        mode:'view',
        deletable:true,
        editable:true,
        showProfile:false,
        userName:'권승주',
        value: '1111 클라우드 Cell은 당대의 빛과 같은 존재로 기은에서 없어서는 안될 존재입니다. 기은의 클라우드를 늘 이끌어주세요~~!!',
        date:'2022.03.02 09:00:00'
    },
    {
        id: 'c1',
        mode:'view',
        deletable:true,
        editable:true,
        showProfile:false,
        userName:'홍길동',
        value: '2222 클라우드 Cell은 당대의 빛과 같은 존재로 기은에서 없어서는 안될 존재입니다. 기은의 클라우드를 늘 이끌어주세요~~!!',
        date:'2022.03.02 09:00:00'
    },
    {
        id: 'c2',
        mode:'view',
        deletable:true,
        editable:true,
        showProfile:false,
        userName:'홍길동',
        value: '3333 클라우드 Cell은 당대의 빛과 같은 존재로 기은에서 없어서는 안될 존재입니다. 기은의 클라우드를 늘 이끌어주세요~~!!',
        date:'2022.03.02 09:00:00'
    },
]