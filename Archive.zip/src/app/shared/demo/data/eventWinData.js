//[이벤트]
export const eventWinData = [
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   {
    name:'권승주',
    num:'12345',
    department:'IT그룹',
    comment:'The-Fast Cloud'
   },
   
]