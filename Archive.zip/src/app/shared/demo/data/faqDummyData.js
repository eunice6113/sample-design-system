//[건의 및 개선 관리]
export const faqDummyData = [
    {
        no: 0,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 1,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 2,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 3,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 4,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 5,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 6,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 7,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 8,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 9,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 10,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 11,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 12,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 13,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 14,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
    {
        no: 15,
        subject: '제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.제목입니다.',
        questioner: '위성규',
        answer: '신재문',
        registerDate: '2022.10.15',
        answerDate: '2022.10.16'
    },
]