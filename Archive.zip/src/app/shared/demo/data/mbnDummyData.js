//메인배너관리
export const mbnDummyData = [
    {
        subject: '제목입니다 1',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 2 제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다제목입니다 ',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 3',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 4',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 5',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 6',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 7',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 8',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 9',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'Y',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',

        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    {
        subject: '제목입니다 10',
        author: '신재문(s12345)',
        registerDate: '2022-10-15',
        useYn: 'N',
        period:'2023.02.20 ~2023.03.20',
    },
    
]