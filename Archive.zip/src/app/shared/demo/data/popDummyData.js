// 팝업관리
export const popDummyData = [
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '토스트',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
    {
        no: 0,
        type: '윈도우',
        subject: '제목입니다',
        author: '신재문',
        dateRange: '2023.02.20 ~ 2023.02.25',
        registerDate: '2022-10-15',
        useYn: 'Y'
    },
   
    
]