//[공지사항]
export const qnaDummyData = [
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
    {
        no: 0,
        type: '[공지사항]',
        subject: '제목입니다',
        
        author: '신재문',
        hit: 100,
        registerDate: '2022-10-15'
    },
]