//[the fast cloud 신청 관리]
export const tfcDummyData = [
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    {
        no: 0,
        businessName: '정보화추진사업 신청을',
        department: 'IT그룹',
        type: '내부사업',
        applicant: '홍길동(12345)',
        applicationDate:'2022.10.15',
        state: '신청',
        manager:'홍길동(12345)'
    },
    
    
]